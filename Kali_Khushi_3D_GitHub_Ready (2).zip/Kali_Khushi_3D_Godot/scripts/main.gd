extends Node3D

const LANE_Z := 0.0
const BULL_X := -3.2
const FLOOR_Y := 0.0

var score := 0
var speed := 8.0
var obstacle: Node3D
var bull: Node3D
var bull_velocity := 0.0
var grounded := true
var game_running := true
var spawn_distance := 18.0
var rng := RandomNumberGenerator.new()

var score_label: Label
var message_label: Label
var restart_button: Button
var touch_hint: Label

func _ready() -> void:
    rng.randomize()
    _build_world()
    _build_bull()
    _spawn_obstacle()
    _build_ui()
    _say("Kali Khushi")

func _process(delta: float) -> void:
    if not game_running:
        return
    if Input.is_action_just_pressed("jump"):
        _jump()
    bull_velocity -= 22.0 * delta
    bull.position.y += bull_velocity * delta
    if bull.position.y <= 0.0:
        bull.position.y = 0.0
        bull_velocity = 0.0
        grounded = true

    obstacle.position.x -= speed * delta
    if obstacle.position.x < -12.0:
        score += 1
        speed = min(speed + 0.25, 15.0)
        score_label.text = "SCORE  " + str(score)
        obstacle.queue_free()
        _spawn_obstacle()

    if abs(obstacle.position.x - BULL_X) < 1.15 and bull.position.y < 1.15:
        _game_over()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and event.pressed:
        _jump()
    elif event is InputEventMouseButton and event.pressed:
        _jump()

func _jump() -> void:
    if not game_running:
        _restart()
        return
    if grounded:
        bull_velocity = 10.5
        grounded = false
        _say("Kali Khushi" if score % 2 == 0 else "Pagal Khushi")

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.sky.sky_material = ProceduralSkyMaterial.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.82, 0.95)
    env.ambient_light_energy = 0.8
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.25
    add_child(sun)

    var camera := Camera3D.new()
    camera.position = Vector3(0, 5.5, 13.5)
    camera.rotation_degrees = Vector3(-18, 0, 0)
    camera.current = true
    add_child(camera)

    var ground := _make_box(Vector3(0, -0.45, 0), Vector3(40, 0.8, 8), Color(0.18, 0.58, 0.25))
    add_child(ground)
    var track := _make_box(Vector3(0, 0.0, 0), Vector3(40, 0.08, 4.0), Color(0.32, 0.34, 0.36))
    add_child(track)

    for i in range(14):
        var stripe := _make_box(Vector3(-18 + i * 3.0, 0.055, 0), Vector3(1.0, 0.025, 0.08), Color(0.95, 0.88, 0.55))
        add_child(stripe)

    for i in range(7):
        var cloud := _make_sphere(Vector3(-12 + i * 4.5, 7.5 + (i % 2), -5), Vector3(1.5, 0.5, 0.5), Color(1,1,1))
        add_child(cloud)

func _build_bull() -> void:
    bull = Node3D.new()
    bull.position = Vector3(BULL_X, 0, 0)
    add_child(bull)

    _add_bull_part(bull, Vector3(-0.15, 0.82, 0), Vector3(1.45, 0.78, 0.72), Color(0.025,0.025,0.035), "body")
    _add_bull_part(bull, Vector3(0.58, 1.22, 0), Vector3(0.72, 0.72, 0.68), Color(0.035,0.035,0.045), "head")
    _add_bull_part(bull, Vector3(0.85, 0.96, 0), Vector3(0.42, 0.28, 0.54), Color(0.38,0.38,0.42), "muzzle")
    _add_bull_part(bull, Vector3(-0.55, 0.38, -0.22), Vector3(0.2, 0.65, 0.2), Color(0.02,0.02,0.025), "leg1")
    _add_bull_part(bull, Vector3(0.35, 0.38, 0.22), Vector3(0.2, 0.65, 0.2), Color(0.02,0.02,0.025), "leg2")
    _add_bull_part(bull, Vector3(0.38, 1.68, -0.27), Vector3(0.12, 0.42, 0.12), Color(0.92,0.86,0.68), "horn1")
    _add_bull_part(bull, Vector3(0.72, 1.68, 0.27), Vector3(0.12, 0.42, 0.12), Color(0.92,0.86,0.68), "horn2")
    _add_bull_part(bull, Vector3(0.84, 1.35, -0.31), Vector3(0.12,0.12,0.08), Color(1,0.85,0.12), "eye1")
    _add_bull_part(bull, Vector3(0.84, 1.35, 0.31), Vector3(0.12,0.12,0.08), Color(1,0.85,0.12), "eye2")

func _add_bull_part(parent: Node3D, pos: Vector3, scale_v: Vector3, color: Color, label: String) -> void:
    var mesh_node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    mesh_node.mesh = mesh
    mesh_node.position = pos
    mesh_node.scale = scale_v
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.72
    mesh_node.material_override = mat
    parent.add_child(mesh_node)

func _spawn_obstacle() -> void:
    obstacle = Node3D.new()
    obstacle.position = Vector3(spawn_distance, 0.0, 0.0)
    add_child(obstacle)
    var block := _make_box(Vector3(0,0.65,0), Vector3(0.85,1.3,0.9), Color(1.0,0.72,0.04))
    obstacle.add_child(block)
    var eye_mat := StandardMaterial3D.new()
    eye_mat.albedo_color = Color(0.15,0.08,0.02)
    var eye := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.07
    sphere.height = 0.14
    eye.mesh = sphere
    eye.position = Vector3(0.18,0.88,0.47)
    eye.material_override = eye_mat
    obstacle.add_child(eye)

func _make_box(pos: Vector3, size_v: Vector3, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size_v
    node.mesh = mesh
    node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.85
    node.material_override = mat
    return node

func _make_sphere(pos: Vector3, scale_v: Vector3, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    node.mesh = mesh
    node.position = pos
    node.scale = scale_v
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    node.material_override = mat
    return node

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    score_label = Label.new()
    score_label.text = "SCORE  0"
    score_label.position = Vector2(28, 18)
    score_label.add_theme_font_size_override("font_size", 30)
    score_label.add_theme_color_override("font_color", Color(0.04,0.06,0.08))
    root.add_child(score_label)

    message_label = Label.new()
    message_label.text = "KALI KHUSHI  •  TAP TO JUMP"
    message_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    message_label.position.y = 22
    message_label.add_theme_font_size_override("font_size", 28)
    message_label.add_theme_color_override("font_color", Color(0.04,0.06,0.08))
    root.add_child(message_label)

    touch_hint = Label.new()
    touch_hint.text = "TAP ANYWHERE TO JUMP"
    touch_hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    touch_hint.position.y = -58
    touch_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    touch_hint.add_theme_font_size_override("font_size", 22)
    touch_hint.add_theme_color_override("font_color", Color(1,1,1))
    root.add_child(touch_hint)

    restart_button = Button.new()
    restart_button.text = "PLAY AGAIN"
    restart_button.visible = false
    restart_button.custom_minimum_size = Vector2(220, 72)
    restart_button.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    restart_button.position = Vector2(-110, 70)
    restart_button.pressed.connect(_restart)
    root.add_child(restart_button)

func _game_over() -> void:
    game_running = false
    message_label.text = "GAME OVER  •  SCORE " + str(score)
    restart_button.visible = true
    touch_hint.text = "PRESS PLAY AGAIN"
    _say("Game over")

func _restart() -> void:
    score = 0
    speed = 8.0
    bull.position.y = 0.0
    bull_velocity = 0.0
    grounded = true
    game_running = true
    score_label.text = "SCORE  0"
    message_label.text = "KALI KHUSHI  •  TAP TO JUMP"
    restart_button.visible = false
    touch_hint.text = "TAP ANYWHERE TO JUMP"
    obstacle.queue_free()
    _spawn_obstacle()

func _say(words: String) -> void:
    # Optional speech is intentionally not required for the game to run.
    pass
