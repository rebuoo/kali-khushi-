KALI KHUSHI 3D - GITHUB READY PROJECT
=====================================

This is a Godot 4.4.1 3D game project with a simple stylized 3D black bull,
tap-to-jump controls, moving yellow obstacle, score, game over and restart.

UPLOAD TO GITHUB:
1. Open https://github.com/new
2. Repository name: kali-khushi-3d
3. Create the repository.
4. Extract this ZIP on your computer.
5. Upload ALL files and folders from inside this folder to the repository.
   IMPORTANT: Include the hidden .github folder.
6. Commit the uploaded files to the main branch.

BUILD APK:
1. Open the repository's Actions tab.
2. Select "Build Kali Khushi 3D Android APK".
3. Click "Run workflow" if it has not started automatically.
4. Wait for the workflow to finish successfully.
5. Open the successful run and download artifact:
   Kali-Khushi-3D-APK
6. Extract the downloaded artifact ZIP. It contains KaliKhushi.apk.

RUN ON PC:
Install Godot 4.4.1, import project.godot, then press F6/F5 to run.

NOTES:
- The package is the complete Godot source project plus a GitHub Actions APK workflow.
- GitHub Actions must be enabled for the repository.
- APK signing uses the export template's debug signing path; this is for testing,
  not a Play Store production release.
- The character is built from 3D primitive shapes (not a detailed animated 3D model).
- Speech lines are shown in the game concept, but device text-to-speech is not
  connected in this starter build.
- If GitHub Actions reports an export preset or Android SDK error, share the
  failed log and it can be corrected for that environment.
